# WALMART FLOW

1. Add to cart button
   1. data-tl-id attribute: ProductPrimaryCTA-cta_add_to_cart_button
2. Check out button
   1. data-tl-id attribute: IPPacCheckOutBtnBottom
3. Continue without account button
   1. data-tl-id attribute: Wel-Guest_cxo_btn
4. Delivery Option page. Continue Button
   1. data-tl-id attribute: button
5. Checkout page. Enter delivery address.
   1. first name. input[name="firstName"]
   2. state is dropdown selector
6. Press enter for next step
7. Enter payment method. credit card info:
   1. same input name pattern
   2. expiration date is dropdown MM/YY
8. Review Order

<https://www.walmart.com/ip/Sony-PlayStation-5/363472942?irgwc=1&sourceid=imp_1WkQl50UWxyLT-ewUx0Mo36HUkE27lU-Pz5OQ00&veh=aff&wmlspartner=imp_1442478&clickid=1WkQl50UWxyLT-ewUx0Mo36HUkE27lU-Pz5OQ00&sharedid>=
