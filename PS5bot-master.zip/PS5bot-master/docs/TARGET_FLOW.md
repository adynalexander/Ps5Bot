# Target Flow

1. Sign in
2. Ship it button
3. Coverage plan popup. Click "Decline coverage"
4. Added to cart popup. Click "View cart & checkout"
5. I'm ready to check out button
   - option for standard shipping vs order pickup
6. Enter addess
7. Save and Continue address
8. Enter payment
   1. debit card or paypal radio button
   2. enter credit card or click pay with paypal
9. Click "Place your order"****
10. ???

Uncertanties:

- What happens after "Place your order"?
