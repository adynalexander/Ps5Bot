# TODO

- [x] Target scraper
- [ ] GameStop
- [x] - Walmart
- [x] Stock refresh
  - [x] PlayStation Direct
  - [x] Target
  - [ ] GameStop
- [x] If in-stock, run scraper
- [x] Option to run two checkouts from different sites in parallel
  - When attempting to place order at site A, site B should pause when reaching the final stage. If site A order fails, execute order in site B
- [ ] UTs
