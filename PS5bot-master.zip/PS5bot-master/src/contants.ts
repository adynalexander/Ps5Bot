export const TARGET = 'Target'
export const WALMART = 'Walmart'
export const PLAYSTATION_DIRECT = 'PlayStation Direct'
