# BESTBUY_FLOW

1. Add to Cart button
   1. no ids, xpath?
2. Go to Cart button in popup
   1. can just go to /cart
3. checkout button
4. continue as guest
5. Enter contact information form
   1. Input have id
      1. user.emailAddress
      2. user.phone
6. continue to payment information button
   1. cant press enter
7. Enter card and address
   1. card number is input
      1. optimized-cc-card-number
   2. address
      1. payment.billingAddress.firstName
      2. payment.billingAddress.lastName
      3. payment.billingAddress.street
      4. payment.billingAddress.city
      5. payment.billingAddress.zipcode
      6. select state
         1. payment.billingAddress.state
         2. 2 letters only
8. Place order button.not sure if have to review first

https://www.bestbuy.com/site/sony-playstation-5-digital-edition-console/6430161.p?skuId=6430161
